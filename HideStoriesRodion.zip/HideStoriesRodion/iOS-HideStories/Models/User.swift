//
//  User.swift
//  iOS-HideStories
//
//  Created by BOTTAK on 3/12/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit

final class User {
    
    let id: String
    
    let username: String
    
    let avatarUrl: URL
    
    var avatarImage: UIImage?
    
    init(id: String, username: String, avatarUrl: URL) {
        self.id = id
        self.username = username
        self.avatarUrl = avatarUrl
    }
}
