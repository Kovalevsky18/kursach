//
//  Story.swift
//  iOS-HideStories
//
//  Created by BOTTAK on 3/12/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit

final class Story {
    
    let imageUrl: URL
    
    let videoUrl: URL?
    
    let timestamp: Int
    
    var image: UIImage?
    
    init(imageUrl: URL, timestamp: Int, videoUrl: URL?) {
        self.imageUrl = imageUrl
        self.timestamp = timestamp
        self.videoUrl = videoUrl
    }
}

