//
//  StoryTransitionManager.swift
//  iOS-HideStories
//
//  Created by BOTTAK on 3/12/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit

class StoryTransitionManager: NSObject {
    
    private let animator = StoryTransitionAnimator()
}

extension StoryTransitionManager: UIViewControllerTransitioningDelegate {
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        animator.presenting = true
        return animator
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        animator.presenting = false
        return animator
    }
}
