import Foundation
import UIKit

class FavoriteUser: Codable {
    
    var avatarImage: UIImage?
    var isLiked :Bool?
    var id: String?
    var username: String?
    var avatarUrl: URL?
    
    private enum CodingKeys: String, CodingKey { // набор ключей под которыми будут упаковываться проперти
        case avatarImage
        case isLiked
        case id
        case username
        case avatarUrl
    }
    
    init() {}
    
    required init(from decoder: Decoder) throws { //обязательная инициализация //процедура сборки объекта из даты
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let data = try container.decode(Data.self, forKey: .avatarImage)
        avatarImage = UIImage(data: data)
        isLiked = try container.decode(Bool.self, forKey: .isLiked)
        id = try container.decode(String.self, forKey: .id)
        username = try container.decode(String.self, forKey: .username)
        avatarUrl = try container.decode(URL.self,forKey: .avatarUrl)
    }
    
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        if let photo = avatarImage {
            guard let data = photo.jpegData(compressionQuality: 1) else {
                return
            }
            try container.encode(data, forKey: CodingKeys.avatarImage)
            try container.encode(self.isLiked, forKey: CodingKeys.isLiked)
            try container.encode(self.id,forKey: CodingKeys.id)
            try container.encode(self.username, forKey: CodingKeys.username)
            try container.encode(self.avatarUrl, forKey: CodingKeys.avatarUrl)
        }
    }
}

