
import UIKit

final class MainVC: UIViewController {
    
    private let searchUsersVC = SearchUsersVC()
    
    private let topBar: ClearTopBar = {
        let topBar = ClearTopBar()
        topBar.title = "Hide Stories"
        topBar.includeRightButton = true
        topBar.includeLeftButton = true
        topBar.setLeftButtonImage(UIImage(named:"favorites"))
        topBar.setRightButtonImage(UIImage(named: "SettingsIcon"))
        topBar.titleFont = Fonts.topBar
        return topBar
    }()

    private let advView: UIView = {
        let advView = UIView()
        advView.backgroundColor = .black
        return advView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        timer()
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        layoutViews()
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        
        view.addSubview(topBar)
        addChildController(searchUsersVC)
        
        searchUsersVC.delegate = self
       
        
        topBar.onRightButtonTapped = { [weak self] in
            self?.settingsButtonTapped()
        }
        topBar.onLeftButtonTapped = { [weak self] in
            self?.favoriteButtonPressed()
            
        }
    }
    private func favoriteButtonPressed(){
        let favoriteVC = FavoritesVC()
        navigationController?.pushViewController(favoriteVC, animated: true)
         view.endEditing(true)
    }
    
    func timer(){
        let timer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { timer in
            self.view.addSubview(self.advView)
        }
    }
    
    private func layoutViews() {
        topBar.frame.origin.x = 0
        topBar.frame.origin.y = currentDevice == .iPhoneX ? UIProperties.iPhoneXTopInset : 0
        topBar.frame.size = CGSize(width: view.frame.width, height: 86)
        topBar.rightButtonCenterInset = -2
        
        advView.frame.origin.x = 0
        advView.frame.origin.y =  searchUsersVC.view.frame.maxY
        advView.frame.size = CGSize(width: view.frame.width, height: 80)
        
        searchUsersVC.view.frame.origin.x = 0
        searchUsersVC.view.frame.origin.y = topBar.frame.maxY - 10
        searchUsersVC.view.frame.size.width = view.frame.width
        searchUsersVC.view.frame.size.height = view.frame.height - searchUsersVC.view.frame.minY - advView.frame.height
    }
    
    private func settingsButtonTapped() {
        let settingsVC = SettingsVC()
        navigationController?.pushViewController(settingsVC, animated: true)
        view.endEditing(true)
    }
}

extension MainVC: SearchUsersDelegate {
    
    func userTapped(_ user: User) {
        let storiesVC = StoriesVC()
        storiesVC.user = user
        navigationController?.pushViewController(storiesVC, animated: true)
    }
}

