//
//  asaViewController.swift
//  iOS-HideStories
//
//  Created by Родион Ковалевский on 3/16/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit

class asaViewController: UIViewController {
    var story:Story!
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let selectedImage = UIImage(named: "down-arrow") else {
                   print("Image not found!")
                   return
               }
               UIImageWriteToSavedPhotosAlbum(selectedImage, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)

    }
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            showAlertWith(title: "Save error", message: error.localizedDescription)
        } else {
            showAlertWith(title: "Saved!", message: "Your image has been saved to your photos.")
        }
    }

    func showAlertWith(title: String, message: String){
        let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default))
        present(ac, animated: true)
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
