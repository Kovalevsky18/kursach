//
//  StoryVC.swift
//  iOS-HideStories
//
//  Created by BOTTAK on 3/12/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit
import AVFoundation
final class StoryVC: UIViewController {
    let imagePicker = UIImagePickerController()
    var story: Story!
    
    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private let closeButton: RoundButton = {
        let button = RoundButton(type: .custom)
        button.setImage(UIImage(named: "CloseIcon"))
        button.backgroundColor = UIColor(white: 1, alpha: 0.7)
        button.setShadowOpacity(0.26)
        button.setShadowColor(.gray)
        button.setShadowRadius(12)
        return button
    }()
    
    private let downloadButton:RoundButton = {
        let button = RoundButton(type: .custom)
        button.setImage(UIImage(named: "down-arrow"))
        button.backgroundColor = UIColor(white: 1, alpha: 0.7)
        button.setShadowOpacity(0.26)
        button.setShadowColor(.gray)
        button.setShadowRadius(12)
        return button
    }()
    
    private var playerLayer: AVPlayerLayer?
    
    private var videoLooper: AVPlayerLooper?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        self.imagePicker.delegate = self
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        layoutViews()
    }
    
    private func setupViews() {
        view.backgroundColor = .black
        
        view.addSubview(imageView)
        view.addSubview(closeButton)
        view.addSubview(downloadButton)
        imageView.image = story.image
        
        scaleDownImageView()
        
        if let videoUrl = story.videoUrl {
            playerLayer = AVPlayerLayer()
            imageView.layer.addSublayer(playerLayer!)
           prepareForPlayingVideo(videoUrl)
            print(videoUrl)
            playVideo()
        }
        
        closeButton.addTarget(self, action: #selector(closeButtonTapped), for: .touchUpInside)
        downloadButton.addTarget(self, action: #selector(downloadButtonTapped), for: .touchUpInside)
    }
    
    
    private func layoutViews() {
        imageView.frame = view.bounds
        playerLayer?.frame = imageView.bounds
        downloadButton.frame.size = CGSize(width: 43, height: 43)
        downloadButton.frame.origin.x = view.frame.minX + closeButton.frame.width + 20
        downloadButton.frame.origin.y = currentDevice == .iPhoneX ? 58 + UIProperties.iPhoneXTopInset : 20
        
        closeButton.frame.size = CGSize(width: 43, height: 43)
        closeButton.frame.origin.x = view.frame.width - closeButton.frame.width - 20
        closeButton.frame.origin.y = currentDevice == .iPhoneX ? 58 + UIProperties.iPhoneXTopInset : 20
    }
    
    func scaleUpImageView() {
        imageView.transform = .identity
    }
    
    func scaleDownImageView() {
        imageView.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
    }
    
    
    @objc private func closeButtonTapped() {
        dismiss(animated: true)
    }
    @objc private func downloadButtonTapped() {
        guard let selectedImage = story.image else {
                   print("Image not found!")
                   return
               }
               UIImageWriteToSavedPhotosAlbum(selectedImage, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
           if let error = error {
               showAlertWith(title: "Save error", message: error.localizedDescription)
           } else {
               showAlertWith(title: "Saved!", message: "Your image has been saved to your photos.")
           }
       }

       func showAlertWith(title: String, message: String){
           let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
           ac.addAction(UIAlertAction(title: "OK", style: .default))
           present(ac, animated: true)
       }
    

    
    
    private func prepareForPlayingVideo(_ videoUrl: URL) {
        let asset = AVAsset(url: videoUrl)
        let item = AVPlayerItem(asset: asset)

        let player = AVQueuePlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = false
        videoLooper = AVPlayerLooper(player: player, templateItem: item)
        playerLayer!.player = player
    }
    
    private func playVideo() {
        playerLayer?.player?.play()
    }
}
extension StoryVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            self.imagePicker.dismiss(animated: true)
        }
    }
}
