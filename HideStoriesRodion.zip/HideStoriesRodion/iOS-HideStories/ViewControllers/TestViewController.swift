//
//  TestViewController.swift
//  iOS-HideStories
//
//  Created by Родион Ковалевский on 3/16/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit
import Photos
class TestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
saveVideo(videoUrl: <#T##URL#>)
            }
    func saveVideo(videoUrl:URL) {
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: videoUrl)
        }) { saved, error in
            if saved {
                let alertController = UIAlertController(title: "Your video was successfully saved", message: nil, preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(defaultAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }

    

}
