//
//  DevelopersVC.swift
//  iOS-HideStories
//
//  Created by Родион Ковалевский on 3/29/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//
import UIKit
import Foundation
import MessageUI
final class DevelopersVC:UIViewController {
  
    let avatarDev = [UIImage(named: "2"),UIImage(named: "4"),UIImage(named: "1")]
    let nameDev = ["Vasily Piankevich","Rodion Kovalevsky","Pavel Dubrouski",]
  
    private let collectionView: UICollectionView = {
      let layout = UICollectionViewFlowLayout()
      layout.sectionInset.bottom = 20
      layout.minimumLineSpacing = 14
      let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
      collectionView.contentInsetAdjustmentBehavior = .never
      collectionView.backgroundColor = .white
      return collectionView
  }()
    
    private let topBar: ClearTopBar = {
           let topBar = ClearTopBar()
           topBar.title = "Developers"
           topBar.includeLeftButton = true
           topBar.setLeftButtonImage(UIImage(named: "BackIcon"))
           topBar.titleFont = UIFont(name: Fonts.circeBold, size: 21)!
           return topBar
       }()
    override func viewWillLayoutSubviews() {
           super.viewWillLayoutSubviews()
           layoutViews()
       }
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }

    private func setupViews() {
           view.backgroundColor = .white
           view.addSubview(topBar)
           view.addSubview(collectionView)
           topBar.onLeftButtonTapped = { [unowned self] in
               self.tapBackButton()
           }
        collectionView.register(UserCell.self, forCellWithReuseIdentifier: UserCell.reuseId)
        collectionView.delegate = self
               collectionView.dataSource = self
       }
     private func tapBackButton() {
            navigationController?.popViewController(animated: true)
        }
    private func layoutViews() {
           topBar.frame.origin.x = 0
           topBar.frame.origin.y = currentDevice == .iPhoneX ? UIProperties.iPhoneXTopInset : 0
        topBar.frame.size = CGSize(width: view.frame.width, height: 84)
        
        collectionView.frame.origin.y = topBar.frame.maxY
              collectionView.frame.size.width = view.frame.width
              collectionView.center.x = topBar.center.x
              collectionView.frame.size.height = view.frame.height - collectionView.frame.minY
              
              collectionView.contentInset.top = 18
              collectionView.scrollIndicatorInsets.top = collectionView.contentInset.top
        
    }
    func sendEmail(gmail:String){
        if MFMailComposeViewController.canSendMail() {
           let mail = MFMailComposeViewController()
           mail.setToRecipients([gmail])
           mail.setSubject("HideStroies")
           mail.setMessageBody("", isHTML: true)
           mail.mailComposeDelegate = self
           if let filePath = Bundle.main.path(forResource: "sampleData", ofType: "json") {
              if let data = NSData(contentsOfFile: filePath) {
                 mail.addAttachmentData(data as Data, mimeType: "application/json" , fileName: "sampleData.json")
              }
           }
           present(mail, animated: true)
        }
        else {
           print("Email cannot be sent")
        }
}
    
    
}


extension DevelopersVC: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return avatarDev.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: UserCell.reuseId, for: indexPath) as! UserCell
        cell.setIcon(UIImage(named: "icons8-new-message-50"))
        cell.setAvatar(avatarDev[indexPath.row])
        cell.setUsername(nameDev[indexPath.row])
        return cell
    }
    
}
extension DevelopersVC: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch indexPath.item{
        case 0:
            sendEmail(gmail: "vasilii.piankevich@gmail.com")
        case 1:
            sendEmail(gmail: "kovalevsky18work@gmail.com")
        case 2:
            sendEmail(gmail: "pasha_dubrovskiy@mail.ru")
        default: break
            
        }
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width - 32, height: UIProperties.userCellHeight)
    }
}
extension DevelopersVC:MFMailComposeViewControllerDelegate{
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
       if let _ = error {
          self.dismiss(animated: true, completion: nil)
       }
       switch result {
          case .cancelled:
          print("Cancelled")
          break
          case .sent:
          print("Mail sent successfully")
          break
          case .failed:
          print("Sending mail failed")
          break
          default:
          break
       }
       controller.dismiss(animated: true, completion: nil)
    }
}
