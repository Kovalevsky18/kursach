//
//  UserDefaultsKeys.swift
//  iOS-HideStories
//
//  Created by BOTTAK on 3/12/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import Foundation

enum UserDefaultsKeys {
    
    static let appOpenedCount = "appOpenedCount"
}
