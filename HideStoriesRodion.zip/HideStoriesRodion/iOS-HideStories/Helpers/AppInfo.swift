//
//  AppInfo.swift
//  iOS-HideStories
//
//  Created by BOTTAK on 3/12/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import Foundation

enum AppInfo {
    
    static let appId = ""
    
    static let appName = ""
}

