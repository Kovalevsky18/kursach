//
//  UIProperties.swift
//  iOS-HideStories
//
//  Created by BOTTAK on 3/12/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit

enum UIProperties {
    
    static let iPhoneXTopInset: CGFloat = 32
    
    static var userCellHeight: CGFloat {
        switch currentDevice {
        case .iPhone5 : return 74
        default : return 76
        }
    }
}
