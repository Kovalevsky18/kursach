//
//  UserNotification.swift
//  iOS-HideStories
//
//  Created by Родион Ковалевский on 3/19/20.
//  Copyright © 2020 BOTTAK. All rights reserved.
//

import UIKit
import UserNotifications
class UserNotifications:NSObject{
    static let shared = UserNotifications()
    
    func requestNotification(){
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound,.badge]) { (success, error) in
            if success{
                
                       let content = UNMutableNotificationContent()
                       content.title = "HideStory"
                       content.body = "Mary made new story,look first"
                       content.sound = UNNotificationSound.default
                       
                       let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
                       let request = UNNotificationRequest(identifier: "notification", content: content, trigger: trigger)
                       UNUserNotificationCenter.current().add(request) { (error) in
                           if let error = error{
                               print("error")
                           }
                       }
            }
            else{
                print(error?.localizedDescription)
            }
        }
    }
    
   
}
//extension UserNotifications:UNUserNotificationCenterDelegate{
//    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
//        print("did")
//    }
//    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
//        completionHandler([.alert])
//    }
//}
